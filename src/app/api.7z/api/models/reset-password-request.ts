/* tslint:disable */
/* eslint-disable */
export interface ResetPasswordRequest {
  email?: string | null;
  newPassword?: string | null;
  token?: string | null;
}
