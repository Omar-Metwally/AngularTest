/* tslint:disable */
/* eslint-disable */
export enum MealSizeOption {
  $0 = 0,
  $1 = 1,
  $2 = 2
}
