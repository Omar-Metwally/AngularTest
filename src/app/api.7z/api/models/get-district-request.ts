/* tslint:disable */
/* eslint-disable */
export interface GetDistrictRequest {
  id?: string;
  name?: string | null;
}
