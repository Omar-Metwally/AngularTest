/* tslint:disable */
/* eslint-disable */
export enum SubscriptionStatus {
  $0 = 0,
  $1 = 1,
  $2 = 2
}
