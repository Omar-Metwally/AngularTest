/* tslint:disable */
/* eslint-disable */
export interface GetBuildingRequest {
  id?: string;
  name?: string | null;
}
