/* tslint:disable */
/* eslint-disable */
export interface TokenRequestModel {
  email?: string | null;
  password?: string | null;
}
