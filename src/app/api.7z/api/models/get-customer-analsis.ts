/* tslint:disable */
/* eslint-disable */
export interface GetCustomerAnalsis {
  customerID?: string | null;
  customerImage?: string | null;
  customerName?: string | null;
  totalCost?: number;
  totalOrders?: number;
  totalRevenue?: number;
}
