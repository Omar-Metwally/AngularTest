/* tslint:disable */
/* eslint-disable */
export enum SortBy {
  $0 = 0,
  $1 = 1,
  $2 = 2,
  $3 = 3,
  $4 = 4
}
