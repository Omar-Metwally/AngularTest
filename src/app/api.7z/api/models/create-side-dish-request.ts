/* tslint:disable */
/* eslint-disable */
export interface CreateSideDishRequest {
  image?: string | null;
  name?: string | null;
}
