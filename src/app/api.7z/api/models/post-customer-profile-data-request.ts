/* tslint:disable */
/* eslint-disable */
export interface PostCustomerProfileDataRequest {
  buildingID?: string;
  firstName?: string | null;
  image?: string | null;
  lastName?: string | null;
  phoneNumber?: string | null;
}
