/* tslint:disable */
/* eslint-disable */
export interface GetChiefAnalyticsRequest {
  chiefID?: string | null;
  chiefName?: string | null;
  image?: string | null;
  phoneNumber?: string | null;
  totalCost?: number;
  totalRevenue?: number;
}
