/* tslint:disable */
/* eslint-disable */
export interface AddRoleModel {
  role?: string | null;
  userId?: string | null;
}
