/* tslint:disable */
/* eslint-disable */
export interface UpdateSubscriptionMealOptionQuantityRequest {
  deliveryDate?: string;
  mealOptionID?: string;
  quantity?: number;
  subscriptionID?: string;
}
