/* tslint:disable */
/* eslint-disable */
export interface Email {
  email?: string | null;
}
