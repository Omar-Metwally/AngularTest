/* tslint:disable */
/* eslint-disable */
export interface GetChartData {
  date?: string;
  orderCount?: number;
}
