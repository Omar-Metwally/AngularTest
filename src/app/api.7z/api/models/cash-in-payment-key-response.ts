/* tslint:disable */
/* eslint-disable */
export interface CashInPaymentKeyResponse {
  token?: string | null;
}
