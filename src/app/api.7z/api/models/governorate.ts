/* tslint:disable */
/* eslint-disable */
export interface Governorate {
  id?: string;
  name?: string | null;
}
