/* tslint:disable */
/* eslint-disable */
import { GetCartRequest } from '../models/get-cart-request';
export interface GetCartRequestCartResult {
  data?: GetCartRequest;
  errors?: Array<string> | null;
}
