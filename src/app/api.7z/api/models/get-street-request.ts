/* tslint:disable */
/* eslint-disable */
export interface GetStreetRequest {
  id?: string;
  name?: string | null;
}
