/* tslint:disable */
/* eslint-disable */
import { MealSizeOption } from '../models/meal-size-option';
export interface SelectedSideDish {
  mealSideDishID?: string;
  mealSideDishOptionID?: string;
  sideDishSizeOption?: MealSizeOption;
}
