/* tslint:disable */
/* eslint-disable */
export interface UpdateSubscriptionDayDataRequest {
  deliveryDate?: string;
  mealOptionID?: string;
  newDeliveryDate?: string;
  newMealOptionID?: string;
  quantity?: number;
  subscriptionID?: string;
}
