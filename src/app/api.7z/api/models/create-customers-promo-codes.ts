/* tslint:disable */
/* eslint-disable */
export interface CreateCustomersPromoCodes {
  customersID?: Array<string> | null;
  promoCodeID?: string | null;
}
