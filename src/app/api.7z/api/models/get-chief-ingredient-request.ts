/* tslint:disable */
/* eslint-disable */
import { FoodIngredient } from '../models/food-ingredient';
export interface GetChiefIngredientRequest {
  ingredient?: FoodIngredient;
  pricePerKilo?: number;
}
