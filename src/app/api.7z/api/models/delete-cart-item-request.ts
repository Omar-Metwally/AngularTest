/* tslint:disable */
/* eslint-disable */
export interface DeleteCartItemRequest {
  cartItemID?: number;
}
