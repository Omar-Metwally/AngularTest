/* tslint:disable */
/* eslint-disable */
import { FoodIngredient } from '../models/food-ingredient';
export interface AddIngredient {
  amountInGrams?: number;
  foodIngredient?: FoodIngredient;
}
