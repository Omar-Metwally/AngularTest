/* tslint:disable */
/* eslint-disable */
export interface UpsertPromoCodeRequest {
  createDate?: string;
  expireDate?: string;
  id?: string | null;
  maxDiscount?: number;
  name?: string | null;
  percentage?: number;
}
