/* tslint:disable */
/* eslint-disable */
export interface GetMealReview {
  customerImage?: string | null;
  customerName?: string | null;
  rating?: number;
  reviewDate?: string;
  reviewText?: string | null;
}
