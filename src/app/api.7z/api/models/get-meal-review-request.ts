/* tslint:disable */
/* eslint-disable */
export interface GetMealReviewRequest {
  createdAt?: string;
  customerID?: string | null;
  description?: string | null;
  fullScreenImage?: string | null;
  mealId?: string;
  rating?: number;
  thumbnailImage?: string | null;
  title?: string | null;
  updatedAt?: string;
}
