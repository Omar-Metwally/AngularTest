/* tslint:disable */
/* eslint-disable */
export interface CreateSubscriptionMealOptionRequest {
  mealOptionID?: string;
  quantity?: number;
}
