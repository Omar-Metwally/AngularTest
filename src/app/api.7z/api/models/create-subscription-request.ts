/* tslint:disable */
/* eslint-disable */
export interface CreateSubscriptionRequest {
  customerID?: string | null;
  promoCodeID?: string | null;
}
