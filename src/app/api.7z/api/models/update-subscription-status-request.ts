/* tslint:disable */
/* eslint-disable */
import { SubscriptionStatus } from '../models/subscription-status';
export interface UpdateSubscriptionStatusRequest {
  id?: string;
  subscriptionStatus?: SubscriptionStatus;
}
