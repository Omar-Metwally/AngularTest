/* tslint:disable */
/* eslint-disable */
export interface GetCustomerProfileDataRequest {
  buildingID?: string | null;
  districtID?: string | null;
  firstName?: string | null;
  image?: string | null;
  lastName?: string | null;
  phoneNumber?: string | null;
  streetID?: string | null;
}
