/* tslint:disable */
/* eslint-disable */
import { MealSizeOption } from '../models/meal-size-option';
export interface AddMealSideDishOption {
  sideDishID?: string;
  sideDishSizeOption?: MealSizeOption;
}
