/* tslint:disable */
/* eslint-disable */
export interface UpsertChiefDataRequest {
  apartmentNumber?: string | null;
  buildingID?: string | null;
  chiefImage?: string | null;
  closeTime?: string | null;
  coverImage?: string | null;
  description?: string | null;
  firstName?: string | null;
  floorNumber?: string | null;
  governmentID?: string | null;
  healthCertImage?: string | null;
  lastName?: string | null;
  phoneNumber?: string | null;
  startTime?: string | null;
}
