/* tslint:disable */
/* eslint-disable */
export interface UpdateSideDishRequest {
  id?: string;
  image?: string | null;
  name?: string | null;
}
