/* tslint:disable */
/* eslint-disable */
export interface DeleteSubscriptionDayDataRequest {
  deliveryDate?: string;
  mealOptionID?: string;
  subscriptionID?: string;
}
