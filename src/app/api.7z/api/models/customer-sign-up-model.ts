/* tslint:disable */
/* eslint-disable */
export interface CustomerSignUpModel {
  email?: string | null;
  firstName?: string | null;
  lastName?: string | null;
  password?: string | null;
}
