/* tslint:disable */
/* eslint-disable */
export interface GetWaitingUserList {
  email?: string | null;
  name?: string | null;
  phoneNumber?: string | null;
  signedUpDate?: string | null;
  userID?: string | null;
}
