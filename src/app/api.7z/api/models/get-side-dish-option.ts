/* tslint:disable */
/* eslint-disable */
import { MealSizeOption } from '../models/meal-size-option';
export interface GetSideDishOption {
  availableQuantity?: number;
  price?: number;
  sideDishSizeOption?: MealSizeOption;
}
