/* tslint:disable */
/* eslint-disable */
export interface CashInCallback {
  obj?: any | null;
  type?: string | null;

  [key: string]: any | any | null | string | null | undefined;
}
